//
//  SecondViewController.swift
//  Tic Tac Toe
//
//  Created by HYUNGJIN KIM on 13/04/2018.
//  Copyright © 2018 HYUNGJIN KIM. All rights reserved.
//
// The Swift Guy, 2016, How to Make A Tic Tac Toe Game In Xcode8, retrieved from 3 April 2018, <https://www.youtube.com/watch?v=AIPiMs_jtco>

import UIKit
import AVFoundation

class SecondViewController: UIViewController {
    
    var player : AVAudioPlayer = AVAudioPlayer()    // This is for music
    var history = ""       // This is for history that who has won
    var list = ""          // This is for history
    
        override func viewDidLoad() {
        super.viewDidLoad()
        do{
            let audioPath = Bundle.main.path(forResource: "adele_hello", ofType: "mp3")
            try player = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!)as URL)
        }
        catch
        {}

        // Do any additional setup after loading the view.
    }
    
    // This function use for music player
    @IBAction func music(_ sender: UISwitch) {
        if (sender.isOn == true)
        {
            player.play()
        }
        else{
            player.pause()
        }
    }

    var activePlayer = 1    // This is for player who is player 1 or player 2
    var gameState = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]        // This is 4x4 grid so that they are 16 numbers
    
    let winningCombinations = [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9, 10, 11], [12, 13, 14, 15],    // This is for 4 rows
                               [0, 4, 8, 12], [1, 5, 9, 13], [2, 6, 10, 14], [3, 7, 11, 15],    // This is for 4 columns
                               [0, 5, 10, 15], [3, 6, 9, 12]]                                   // This is for 2 diagonal
    var gameIsActive = true
    
    var counter1 = 0    // This is count for player 1
    var counter2 = 0    // This is count for player 2
    //var time = 0
    //var timer = Timer()
    
    @IBOutlet weak var wonLabel: UILabel!
    @IBOutlet weak var p1Score: UILabel!
    @IBOutlet weak var p2Score: UILabel!
    /*
    @IBOutlet weak var timeLabel: UILabel!
    @IBAction func TimeButton(_ sender: UIButton) {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(SecondViewController.action(_:)), userInfo: nil, repeats: true)
    }
    func action()
    {
        time += 1
        timeLabel.text = String(time)
    }
    */
    
    // This is back button
    @IBAction func back(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    // When user click the button it sould be action
    @IBAction func action(_ sender: AnyObject) {
        if (gameState[sender.tag-1] == 0 && gameIsActive == true)   // Tag sould be subtact 1 because button tag set from 1
        {
            // It is a function to jump to the another player when the first player clicks on one of the button
            gameState[sender.tag-1] = activePlayer
            
            // So that when player click the some place it should be x or o. If x plaeced some where, o will be plaece next time
            if(activePlayer == 1)
            {
                sender.setImage(UIImage(named: "X.png"), for:UIControlState())
                activePlayer = 2
            }
            else{
                sender.setImage(UIImage(named: "O.png"), for:UIControlState())
                activePlayer = 1
            }
        }
        
        // Match that any line completed. If any line was complete, the message will be show that who has won on label.
        for combination in winningCombinations
        {
            if (gameState[combination[0]] != 0
                && gameState[combination[0]] == gameState[combination[1]]
                && gameState[combination[1]] == gameState[combination[2]]
                && gameState[combination[2]] == gameState[combination[3]])
            {
                gameIsActive = false
                
                if gameState[combination[0]] == 1
                {
                    history = "Player1 HAS WON!"
                    list = list + "\n" + history    // Save a history for show history that who has won
                    wonLabel.text = history
                    wonLabel.isHidden = false
                    reStartButton.isHidden = false
                    counter1 += 1
                    p1Score.text = "\(counter1)"
                    return
                }
                else{
                    history = "Player2 HAS WON!"
                    list = list + "\n" + history
                    wonLabel.text = history
                    wonLabel.isHidden = false
                    reStartButton.isHidden = false
                    counter2 += 1
                    p2Score.text = "\(counter2)"
                    return
                }
            }
        }
        
        gameIsActive = false
        
        // If someone completed line, the game active will stop.
        for i in gameState
        {
            if i == 0
            {
                gameIsActive = true
                break
            }
        }
        
        // If anyone couldn't make a line, it sould be draw.
        // The gameIsActive will be false when grid is full.
        if gameIsActive == false
        {
            history = "just a draw"
            list = list + "\n" + history
            wonLabel.text = history
            wonLabel.isHidden = false
            reStartButton.isHidden = false
            counter1 += 1
            p1Score.text = "\(counter1)"
            counter2 += 1
            p2Score.text = "\(counter2)"
            return
        }
    }
    
    // These functions for choice shpae of X or O
    @IBAction func ChooseX(_ sender: AnyObject) {
        if(activePlayer == 1)
        {
            activePlayer = 1
        }
    }
    
    @IBAction func ChooseO(_ sender: AnyObject) {
        if (activePlayer == 1)
        {
            activePlayer = 2
        }
    }
    
    @IBOutlet weak var reStartButton: UIButton!
    
    // When user click the Restart button, all of functions are reset and start game again
    @IBAction func reStart(_ sender: AnyObject) {
        gameState = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]    // All places of grid are clear
        gameIsActive = true
        activePlayer = 1
        
        reStartButton.isHidden = false
        wonLabel.isHidden = true
        p1Score.text = "0"
        p2Score.text = "0"
        
        for i in 1...16
        {
            let button = view.viewWithTag(i) as! UIButton
            button.setImage(nil, for: UIControlState())
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // This function for show history and go to history controller
    override func prepare(for segue4: UIStoryboardSegue, sender: Any?) {
        let DestViewcontroller : HistoryViewController = segue4.destination as! HistoryViewController
        
        DestViewcontroller.labelText = list
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
