//
//  ViewController.swift
//  Tic Tac Toe
//
//  Created by HYUNGJIN KIM on 13/04/2018.
//  Copyright © 2018 HYUNGJIN KIM. All rights reserved.
//

import UIKit
import AVFoundation
var name = ""

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    // This function for play with player that go to controller of player to player
    @IBAction func Player(_ sender: AnyObject) {
        performSegue(withIdentifier: "segue", sender: self)
    }
    
    // This function for play with AI that go to controller of player to AI
    @IBAction func Computer(_ sender: AnyObject) {
        performSegue(withIdentifier: "segue1", sender: self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

