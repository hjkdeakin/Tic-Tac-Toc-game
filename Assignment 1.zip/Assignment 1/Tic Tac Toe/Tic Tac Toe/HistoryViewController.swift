//
//  HistoryViewController.swift
//  Tic Tac Toe
//
//  Created by HYUNGJIN KIM on 13/04/2018.
//  Copyright © 2018 HYUNGJIN KIM. All rights reserved.
//

import UIKit

class HistoryViewController: UIViewController {

    @IBOutlet weak var History: UITextView!
    var labelText = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        History.text = labelText    // History will shows that who has won

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
