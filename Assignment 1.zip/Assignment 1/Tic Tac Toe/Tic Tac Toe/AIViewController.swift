//
//  AIViewController.swift
//  Tic Tac Toe
//
//  Created by HYUNGJIN KIM on 13/04/2018.
//  Copyright © 2018 HYUNGJIN KIM. All rights reserved.
//
// Hong Ly, 2017, Tic Tac Toe Game - Swift 3 | Xcode 8, retrieved from 3 April 2018, <https://www.youtube.com/watch?v=mpsS3zaSoyU>

import UIKit
import AVFoundation

class AIViewController: UIViewController,
    UIImagePickerControllerDelegate,    // Using for image
    UINavigationControllerDelegate {
    
    let imagePicker = UIImagePickerController()
    var player : AVAudioPlayer = AVAudioPlayer()
    
    var history = ""
    var list = ""
    
    var img1 = UIImage(named: "X.png")  // Set image of X
    var img2 = UIImage(named: "O.png")  // Set image of O
    
    var gridBoard = [[0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0]]    // Make numvers for 4 x 4 grid
    
    var currentPlayer : Int = 1
    
    // Current score
    var p1Score : Int = 0   // Score for player
    var p2Score : Int = 0   // Score for AI
    
    // This function for game start and all grids are clear
    func start(){
        gridBoard = [[0,0,0,0], [0,0,0,0], [0,0,0,0], [0,0,0,0]]
        for button in gridButtons{
            button.setImage(nil, for: .normal)
        }
        currentPlayer = 1
    }
    
    // Choose X or O
    @IBAction func ChooseX(_ sender: UIButton) {
        currentPlayer = 1
    }
    
    @IBAction func ChooseO(_ sender: UIButton) {
        currentPlayer = 2
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        do{
            let audioPath = Bundle.main.path(forResource: "adele_hello", ofType: "mp3")
            try player = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: audioPath!)as URL)
        }
        catch
        {}
        // Do any additional setup after loading the view.
    }
    // Play music
    @IBAction func music(_ sender: UISwitch) {
        if (sender.isOn == true)
        {
            player.play()
        }
        else{
            player.pause()
        }
    }
    
    @IBOutlet var gridButtons: [UIButton]!      // All buttons are combine
    
    let winningCombinations = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16],   // This is for 4 rows
                               [4, 8, 12, 16], [1, 5, 9, 13], [2, 6, 10, 14], [3, 7, 11, 15],   // This is for 4 columns
                               [1, 6, 11, 16], [4, 7, 10, 13]]                                  // This is for 2 diagonals
    
    // Back function
    @IBAction func back(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }

    @IBOutlet var reSetButton: UIButton!
    @IBOutlet var resultLabel: UILabel!
    
    @IBOutlet weak var p1Result: UILabel!
    @IBOutlet weak var p2Result: UILabel!
    
    @IBAction func btnClicked(_ sender: AnyObject) {
        // Divide by 4 because button tag set from 0
        // If i divide by 4 with tag , the quotient or reminder sould be 0, 1, 2 and 3
        // So that quotient go to row and reminder go to column
        let rowIndex = sender.tag / 4
        let colIndex = sender.tag % 4
        
        if gridBoard[rowIndex][colIndex] != 0 {return}
        
        gridBoard[rowIndex][colIndex] = currentPlayer
        
        // It is a function to jump to the another player when the first player clicks on one of the button
        // So that when player click the some place it should be x or o. If x plaeced some where, o will be plaece next time
        if currentPlayer == 1 {
            sender.setImage(img1, for: .normal)
        }
        else if currentPlayer == 2 {
            sender.setImage(img2, for: .normal)
        }
        
        let winner = winlose ()
        
        // This switch function for choice who has won.
        switch winner {
        case 0:
            currentPlayer = (currentPlayer % 2) + 1
        case 1:
            resultLabel.text = "Player 1 has won!"
            alertWinner(playerName: "Player 1")
            
            p1Score += 1
            p1Result.text = "\(p1Score)"
            
            history = "Player1 has won!"
            list = list + "\n" + history
            
            //resultLabel.isHidden = false
            //reSetButton.isHidden = false
        case 2:
            resultLabel.text = "Player 2 has won!"
            alertWinner(playerName: "Player 2")
            
            p2Score += 1
            p2Result.text = "\(p2Score)"
            
            history = "Player2 has won!"
            list = list + "\n" + history
            //resultLabel.isHidden = false
            //reSetButton.isHidden = false
            
        default:
            resultLabel.text = "just a draw"
            history = "just a draw"
            list = list + "\n" + history
            resultLabel.text = history
        }
        
        let (cellIndex, gridRowIndex, gridColIndex, p2Win) = whereToPlay()
        
        gridButtons[cellIndex].setImage(img2, for: .normal)
        gridBoard[gridRowIndex][gridColIndex] = 2
        
        if p2Win == true {
            resultLabel.text = "Player 2 has won!"
            p2Score += 1
            p2Result.text = "\(p2Score)"
            history = "Player2 has won!"
            list = list + "\n" + history
            alertWinner(playerName: "Player 2")
        }
        currentPlayer = 1
    }
    
    // Match line that who complete row, column or diagonal
    func winlose() -> Int {
        // For row
        if gridBoard[0][0] != 0 && gridBoard[0][0] == gridBoard[0][1] && gridBoard[0][1] == gridBoard[0][2] && gridBoard[0][2] == gridBoard[0][3] {
            return gridBoard[0][0]
        }
        if gridBoard[1][0] != 0 && gridBoard[1][0] == gridBoard[1][1] && gridBoard[1][1] == gridBoard[1][2] && gridBoard[1][2] == gridBoard[1][3] {
            return gridBoard[1][0]
        }
        if gridBoard[2][0] != 0 && gridBoard[2][0] == gridBoard[2][1] && gridBoard[2][1] == gridBoard[2][2] && gridBoard[2][2] == gridBoard[2][3] {
            return gridBoard[2][0]
        }
        if gridBoard[3][0] != 0 && gridBoard[3][0] == gridBoard[3][1] && gridBoard[3][1] == gridBoard[3][2] && gridBoard[3][2] == gridBoard[3][3] {
            return gridBoard[3][0]
        }
        // For column
        if gridBoard[0][0] != 0 && gridBoard[0][0] == gridBoard[1][0] && gridBoard[1][0] == gridBoard[2][0] && gridBoard[2][0] == gridBoard[3][0] {
            return gridBoard[0][0]
        }
        if gridBoard[0][1] != 0 && gridBoard[0][1] == gridBoard[1][1] && gridBoard[1][1] == gridBoard[2][1] && gridBoard[2][1] == gridBoard[3][1] {
            return gridBoard[0][1]
        }
        if gridBoard[0][2] != 0 && gridBoard[0][2] == gridBoard[1][2] && gridBoard[1][2] == gridBoard[2][2] && gridBoard[2][2] == gridBoard[3][2] {
            return gridBoard[0][2]
        }
        if gridBoard[0][3] != 0 && gridBoard[0][3] == gridBoard[1][3] && gridBoard[1][3] == gridBoard[2][3] && gridBoard[2][3] == gridBoard[3][3] {
            return gridBoard[3][3]
        }
        // For diagonal
        if gridBoard[0][0] != 0 && gridBoard[0][0] == gridBoard[1][1] && gridBoard[1][1] == gridBoard[2][2] && gridBoard[2][2] == gridBoard[3][3] {
            return gridBoard[3][3]
        }
        if gridBoard[0][3] != 0 && gridBoard[0][3] == gridBoard[1][2] && gridBoard[1][2] == gridBoard[2][1] && gridBoard[2][1] == gridBoard[3][0] {
            return gridBoard[3][0]
        }
        return 0
    }
    
    // This function for show message who has won
    func alertWinner (playerName : String) {
        let alertController = UIAlertController(title: "Alert", message: "\(playerName) Won!", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Ok", style: .default){ (action) -> Void in self.start() }
        
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    // This function for match line
    func whereToPlay() -> (Int, Int, Int, Bool){
        var index = -1
        var draw = 0
        var gridRowIndex = 0
        var gridColIndex = 0
        
        // Matching loop from 0 to 3 that is 4 x 4
        for row in 0...3 {
            for col in 0...3 {
                index = index + 1
                if gridBoard[row][col] == 0
                {
                    gridBoard[row][col] = 2
                    
                    var i = winlose()
                    if i == 2
                    {
                        return (index, row, col, true)
                    }
                    
                    gridBoard[row][col] = 1
                    i = winlose()
                    if i == 1
                    {
                        return (index, row, col, false)
                    }
                    
                    draw = index
                    gridRowIndex = row
                    gridColIndex = col
                    
                    gridBoard[row][col] = 0
                }
            }
        }
        return (draw, gridRowIndex, gridColIndex, false)
    }
    
    // This function for reset
    @IBAction func resetButton(_ sender: UIButton) {
        start()
    }
    
    // This function for show history and go to history controller
    override func prepare(for segue5: UIStoryboardSegue, sender: Any?) {
        let DestViewcontroller : AIHistoryViewController = segue5.destination as! AIHistoryViewController
        DestViewcontroller.labeltext = list
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
